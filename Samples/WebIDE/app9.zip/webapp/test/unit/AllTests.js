sap.ui.define([
	"com/mjzsoft/demo/ui5/app9/test/unit/controller/Main.controller"
], function () {
	"use strict";
});