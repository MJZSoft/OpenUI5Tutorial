# SAPUI5GeneralOdataViewer
An app for viewing OData resources automatically

View sample output in youtube.

https://youtu.be/HQjK33QW6Bk


Installation:
1. Import the project to your WebIde.
2. Add northwind odata service to your WebIde.

https://blogs.sap.com/2018/10/11/how-to-use-northwind-odata-service-with-sap-web-ide-with-trial-account/

3. Run the app. 
