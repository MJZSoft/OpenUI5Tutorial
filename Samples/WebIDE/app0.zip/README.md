# This is a cloned application from https://github.com/SAP/openui5-basic-template-app
# Please clone it directly from that repository for the latest changes. 


![Sample Output](./Output.JPG)
