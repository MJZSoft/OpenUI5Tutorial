sap.ui.define([
	"com/mjzsoft/demo/ui5/app5/test/unit/controller/Main.controller"
], function () {
	"use strict";
});