sap.ui.define([
	"com/mjzsoft/demo/ui5/app8/test/unit/controller/Main.controller"
], function () {
	"use strict";
});