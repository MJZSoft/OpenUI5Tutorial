sap.ui.define([
	"com/mjzsoft/demo/ui5/app4/test/unit/controller/View1.controller"
], function () {
	"use strict";
});