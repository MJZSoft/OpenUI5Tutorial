sap.ui.define([
], function () {
	"use strict";
	document.getElementById("alert").innerHTML = "UI5 has been loaded just now.";
});
