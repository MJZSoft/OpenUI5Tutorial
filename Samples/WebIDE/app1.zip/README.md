# The gool is to show you how does the bootstraping works.    

![Sample Output](./Output.JPG)
