# The gool is to show you how to bootstraping the UI5 library from its original CDN.  


![Sample Output](./Output.JPG)
